# Elderly Patient example - JohnMoehrke RelatedPerson Consent v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Elderly Patient example**

## Example Patient: Elderly Patient example

Security Label: [test health data (Details: ActReason code HTEST = 'test health data')](http://terminology.hl7.org/7.3.0/CodeSystem-v3-ActReason.html)

John Schmidt Other, DoB: 1923-07-25

-------

| | |
| :--- | :--- |
| Contact Detail | WI USA |



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "ex-elderly",
  "meta" : {
    "security" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
      "code" : "HTEST"
    }]
  },
  "name" : [{
    "use" : "usual",
    "family" : "Schmidt",
    "given" : ["John"]
  },
  {
    "use" : "old",
    "family" : "Schnidt",
    "given" : ["John", "Jacob", "Jingle", "Heimer"],
    "period" : {
      "end" : "1960"
    }
  },
  {
    "use" : "official",
    "family" : "Schmidt",
    "given" : ["John", "Jacob", "Jingleheimer"],
    "period" : {
      "start" : "1960-01-01"
    }
  },
  {
    "use" : "nickname",
    "family" : "Schmidt",
    "given" : ["Jack"]
  }],
  "gender" : "other",
  "birthDate" : "1923-07-25",
  "address" : [{
    "state" : "WI",
    "country" : "USA"
  }]
}

```
